Description:

    Tools for manipulating patchsets.

Usage:

    rvm patchset {show,lookup} [patchset]
